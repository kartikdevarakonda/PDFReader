﻿using System;
using System.Web.UI;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.IO;
using System.Text;
using System.Data;

namespace ReadPDFWebApp
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        public void ReadPdfFile(string fileName)
        {
            StringBuilder text = new StringBuilder();

            if (File.Exists(fileName))
            {
                PdfReader pdfReader = new PdfReader(fileName);

                for (int page = 1; page <= pdfReader.NumberOfPages; page++)
                {
                    ITextExtractionStrategy strategy = new SimpleTextExtractionStrategy();
                    string currentText = PdfTextExtractor.GetTextFromPage(pdfReader, page, strategy);

                    currentText = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(currentText)));
                    text.Append(currentText);
                }
                pdfReader.Close();
            }
            else
            {
                // alert msg = "no file found";
            }

            string[] strArr =  text.ToString().Split('\n');

            if (strArr.Length > 0)
            {
                // to get "PO NUMBER" index
                int indPoNum = Array.FindIndex(strArr, row => row.Contains("PO NUMBER")); 

                if (indPoNum > 0)
                {
                    string poValue = strArr[indPoNum + 1].Trim().Split(' ')[1].Trim().ToString();
                    txtponumber.Text = poValue;
                }
            }
        }

        protected void btn_GetValues_Click(object sender, EventArgs e)
        {
            string filename = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
            FileUpload1.SaveAs(Server.MapPath("Files/" + filename));

            ReadPdfFile(Server.MapPath("Files/" + filename));
        }
    }
}